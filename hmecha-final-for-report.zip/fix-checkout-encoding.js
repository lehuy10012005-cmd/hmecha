const fs = require("fs");

const files = [
  "app/checkout/page.tsx"
];

const cp1252 = {
  0x20AC: 0x80,
  0x201A: 0x82,
  0x0192: 0x83,
  0x201E: 0x84,
  0x2026: 0x85,
  0x2020: 0x86,
  0x2021: 0x87,
  0x02C6: 0x88,
  0x2030: 0x89,
  0x0160: 0x8A,
  0x2039: 0x8B,
  0x0152: 0x8C,
  0x017D: 0x8E,
  0x2018: 0x91,
  0x2019: 0x92,
  0x201C: 0x93,
  0x201D: 0x94,
  0x2022: 0x95,
  0x2013: 0x96,
  0x2014: 0x97,
  0x02DC: 0x98,
  0x2122: 0x99,
  0x0161: 0x9A,
  0x203A: 0x9B,
  0x0153: 0x9C,
  0x017E: 0x9E,
  0x0178: 0x9F
};

function hasBadText(text) {
  return /Ã|Ä|Â|áº|á»|Æ|â|ðŸ|\uFFFD/.test(text);
}

function toCp1252Bytes(text) {
  const bytes = [];

  for (const ch of text) {
    const code = ch.codePointAt(0);

    if (cp1252[code]) {
      bytes.push(cp1252[code]);
    } else if (code <= 0xff) {
      bytes.push(code);
    } else {
      const utf8 = Buffer.from(ch, "utf8");
      for (const b of utf8) bytes.push(b);
    }
  }

  return Buffer.from(bytes);
}

function fixOnce(text) {
  return toCp1252Bytes(text).toString("utf8");
}

for (const file of files) {
  if (!fs.existsSync(file)) {
    console.log("Missing:", file);
    continue;
  }

  let text = fs.readFileSync(file, "utf8");

  for (let i = 0; i < 5; i++) {
    if (!hasBadText(text)) break;

    const fixed = fixOnce(text);

    if (fixed === text) break;

    text = fixed;
  }

  text = text.replace(/\uFFFD/g, "");

  fs.writeFileSync(file, text, "utf8");

  console.log("Fixed:", file);
}