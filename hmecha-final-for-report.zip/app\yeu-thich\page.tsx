import WishlistPageClient from "../../components/WishlistPageClient";

export const dynamic = "force-dynamic";

export const metadata = {
  title: "Yêu thích | HMECHA",
  description: "Danh sách sản phẩm yêu thích của khách hàng HMECHA.",
};

export default function WishlistAliasPage() {
  return <WishlistPageClient />;
}